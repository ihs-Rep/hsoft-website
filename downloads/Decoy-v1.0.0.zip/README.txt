Decoy Enterprise v1.0.0 — Hardened Windows Access Control & Domain Filter
Developed by IHSByte Software (https://ihsbyte.com.lk)

INSTALLATION:
1. Extract and launch DecoySetup.exe with Administrator privileges.
2. Follow on-screen wizard to install Decoy on your Windows workstation.
3. Master Administrator Password is configured during setup.
4. Use Viewer Mode in shared environments to mask sensitive categories.

SHA-256 Checksum (DecoySetup.exe):
6CEED64B2A986554B16F11219B836570987A3A900352EA35B26C32F398BB413A
