Firewall Blocker v3.5 — Universal Adobe Suite & CorelDRAW Limiter
Developed by IHSByte Software (https://ihsbyte.com.lk)

INSTALLATION & USAGE:
1. Extract FirewallBlocker.exe from this archive.
2. Right-click FirewallBlocker.exe and select 'Run as administrator' (elevation is required to modify Windows Firewall and Hosts rules).
3. Click 'Block Adobe & Corel' to inject high-speed inbound and outbound blocking rules and sinkholes.
4. Click 'Unblock Everything' anytime to safely restore default network connectivity.

SHA-256 Checksum (FirewallBlocker.exe):
59AD7E05AF9A469EABF79265BC06A5FCFE49C4352E0CEC0668C0F26313DA1296
