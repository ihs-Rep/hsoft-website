MailSafe Backup Service v2.5.0 (Production Release)
Enterprise Windows Data & Outlook Archive (PST/OST) Automated Protection Suite
Developed by IHSBYTE Software (https://ihsbyte.com.lk)

DESCRIPTION:
MailSafe is an enterprise-grade automated Windows data protection and backup utility.
It safeguards Outlook PST/OST email archives, accounting files, and critical directories
with Volume Shadow Copy Service (VSS) snapshotting, automated rolling retention,
and multi-destination redundancy (Local, Removable USB, and SMB Network Shares).

KEY FEATURES:
- VSS-Aware Hot Snapshotting: Back up live, in-use Outlook PST/OST archives without closing apps.
- Multi-Destination Support: Local disks, external USB drives, and authenticated SMB network shares.
- Ephemeral SMB Sessions: Resolves server session exhaustion (Windows Error 67) automatically.
- Automated Retention Pruning: Rolling backup version limits prevent destination disk exhaustion.
- Background Service & Tray Monitoring: Headless execution via Windows Task Scheduler.
- DPAPI Encryption: Zero-cloud, local hardware-backed credential encryption.

INSTALLATION & SETUP:
1. Extract and run MailSafe_Setup_2.5.0.exe with Administrator privileges.
2. Follow setup wizard to install MailSafe on your workstation.
3. Configure backup jobs, source folders (e.g. Outlook files), target destinations, and schedule.
4. MailSafe will silently run backups in the background and notify you upon completion.

SHA-256 Checksum (MailSafe_Setup_2.5.0.exe):
3FD4D0BC1A832B2C396B9F3DF280F2EC1F3E4D1F0B71BE136F2132F9A7C1369B
