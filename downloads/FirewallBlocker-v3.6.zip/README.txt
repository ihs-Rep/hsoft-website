Firewall Blocker v3.6 (Master Edition)
Universal Windows Firewall & Hosts Limiter for Adobe & CorelDRAW Suites
Developed by IHSBYTE Software (https://ihsbyte.com.lk)

CHANGELOG (v3.6):
- Dedicated 'About' screen with official embedded IHSByte 3D Cube Logo.
- Official developer profile with direct email (contact@ihsbyte.com.lk) and website links.
- Assembly metadata officially rebranded to IHSBYTE (Company, Trademark, Copyright).
- Standalone embedded binary resources without external asset dependencies.
- High-speed netsh batch injection engine (< 1 second).

SHA-256 Checksum (FirewallBlocker.exe):
59AD7E05AF9A469EABF79265BC06A5FCFE49C4352E0CEC0668C0F26313DA1296
