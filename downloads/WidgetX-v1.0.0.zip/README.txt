WidgetX v1.0.0 — Modern Minimal Desktop Day Counter & Multi-Widget Suite
Developed by IHSByte Software (https://ihsbyte.com.lk)

INSTALLATION & USAGE:
1. Extract all files to any folder (e.g. C:\Tools\WidgetX or a USB drive).
2. Double-click WidgetX.exe to run.
3. Right-click the widget on your desktop to set target dates, change themes (Glass, Frameless, Frosted), or add multiple widgets.
4. Requires Windows 10 or 11 (64-bit) and .NET 8 Desktop Runtime.

SHA-256 (WidgetX.exe):
280F4A5D7F4236F2DF832F2EEE9B1DD535DC09CD072ADCE41F423A3826542C41
