WidgetX v1.0.0 — Modern Minimal Desktop Day Counter & Multi-Widget Suite
Developed by IHSByte Software (https://ihsbyte.com.lk)

INSTALLATION & USAGE:
1. Extract WidgetX.exe anywhere (e.g. C:\Tools\WidgetX or USB drive).
2. Double click WidgetX.exe to run. No installation or external runtime required (Self-Contained Standalone).
3. Right-click the widget to configure target date/time, toggle glass/frameless mode, lock position, or add multiple widgets.
4. Data is stored locally in Data/settings.json.

SHA-256 Checksum (WidgetX.exe):
92565A6336E46BD17A8A61DB9B2E8EDD9E3077F042B3E6659C32A77CA6AFD8D1
