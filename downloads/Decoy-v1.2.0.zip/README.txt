Decoy Enterprise v1.2.0
Hardened Windows Access Control & Domain Filter
Developed by IHSBYTE Software (https://ihsbyte.com.lk)

CHANGELOG (v1.2.0):
- Official branding alignment under IHSBYTE Software studio.
- Assembly metadata updated: Company: IHSBYTE, Product: Decoy WebBlocker Enterprise.
- Enhanced DecoySetup universal installer with updated cryptographic signing.
- Updated embedded branding, about dialog, and administrative audit protections.
- Hardened domain filtering rules across Windows 11 and 10 browsers.

SHA-256 Checksum (DecoySetup.exe):
6CEED64B2A986554B16F11219B836570987A3A900352EA35B26C32F398BB413A
